/* Shared test suite. Runs in Node (node tests/run.js) and in the browser (open tests.html). */
(function (root) {
  'use strict';
  function suite(Calc, report) {
    var passed = 0, failed = 0;
    function eq(name, actual, expected) {
      var ok = JSON.stringify(actual) === JSON.stringify(expected);
      if (ok) passed++; else failed++;
      report(ok, name, ok ? '' : 'expected ' + JSON.stringify(expected) + ' got ' + JSON.stringify(actual));
    }
    function ok(name, cond) { eq(name, !!cond, true); }

    function mk() { return Calc.emptyState(); }
    function tx(s, type, amount, extra) { s.transactions.push(Object.assign({ id: Calc.uid(), type: type, title: 't', amount: amount, date: Calc.todayStr(), category: 'Other', note: '' }, extra || {})); }

    // --- balance rules (plan B) ---
    var s = mk(); s.openingBalance = 10000; tx(s, 'income', 5000); tx(s, 'expense', 1200);
    eq('balance = opening + income - expense', Calc.balance(s), 13800);
    eq('available equals balance with no goals', Calc.available(s), 13800);

    // --- goals vs available (plan A) ---
    var g = { id: 'g1', name: 'Laptop', target: 60000, date: '', created: Calc.todayStr() }; s.goals.push(g);
    tx(s, 'transfer', 3000, { goalId: 'g1', category: 'Savings' });
    eq('goal saved after contribution', Calc.goalSaved(s, 'g1'), 3000);
    eq('balance unchanged by goal transfer', Calc.balance(s), 13800);
    eq('available drops by contribution', Calc.available(s), 10800);
    eq('what-if uses the same available number', Calc.whatIf(s, { amount: 100 }).available, Calc.available(s));
    tx(s, 'transfer', -1000, { goalId: 'g1', category: 'Savings' });
    eq('withdraw returns money to available', Calc.available(s), 11800);

    // --- amount validation (plan C) ---
    ['', '   ', '0', '-5', 'abc', '12abc', '1e500', '1.234', '99999999999'].forEach(function (v) {
      ok('rejects amount "' + v + '"', !Calc.validateAmount(v).ok);
    });
    eq('accepts 1,250.50', Calc.validateAmount('1,250.50').value, 1250.5);
    eq('accepts number 40', Calc.validateAmount(40).value, 40);
    ok('rejects NaN number', !Calc.validateAmount(NaN).ok);
    ok('allowZero works', Calc.validateAmount('0', { allowZero: true }).ok);

    // --- goal validation ---
    ok('goal needs name', !Calc.validateGoal({ name: '   ', target: '100' }, { available: 500 }).ok);
    ok('goal target zero rejected', !Calc.validateGoal({ name: 'A', target: '0' }, { available: 500 }).ok);
    ok('goal target negative rejected', !Calc.validateGoal({ name: 'A', target: '-4' }, { available: 500 }).ok);
    ok('goal saved above target rejected', !Calc.validateGoal({ name: 'A', target: '100', saved: '200' }, { available: 500 }).ok);
    ok('goal saved above available rejected', !Calc.validateGoal({ name: 'A', target: '1000', saved: '600' }, { available: 500 }).ok);
    ok('goal past date rejected', !Calc.validateGoal({ name: 'A', target: '100', date: '2000-01-01' }, { available: 500 }).ok);
    ok('valid goal accepted', Calc.validateGoal({ name: ' Trip ', target: '1,000', saved: '', date: '' }, { available: 0 }).ok);
    ok('contribution above remaining rejected', !Calc.validateContribution('600', { remaining: 500, available: 9999 }).ok);
    ok('contribution above available rejected', !Calc.validateContribution('600', { remaining: 5000, available: 500 }).ok);
    ok('contribution zero rejected', !Calc.validateContribution('0', { remaining: 5000, available: 500 }).ok);
    ok('withdrawal above saved rejected', !Calc.validateWithdrawal('50', { saved: 40 }).ok);

    // --- transaction validation ---
    var good = { type: 'expense', title: 'Tea', amount: '20', date: Calc.todayStr(), category: 'Food & Dining', note: '' };
    ok('valid transaction accepted', Calc.validateTransaction(good).ok);
    ok('empty title rejected', !Calc.validateTransaction(Object.assign({}, good, { title: '  ' })).ok);
    ok('future date rejected', !Calc.validateTransaction(Object.assign({}, good, { date: '2099-01-01' })).ok);
    ok('impossible date rejected', !Calc.validateTransaction(Object.assign({}, good, { date: '2026-02-31' })).ok);
    ok('wrong category for type rejected', !Calc.validateTransaction(Object.assign({}, good, { category: 'Salary' })).ok);

    // --- what-if verdicts ---
    var w = mk(); w.openingBalance = 1000;
    eq('what-if yes', Calc.whatIf(w, { amount: 100 }).verdict, 'yes');
    eq('what-if caution', Calc.whatIf(w, { amount: 700 }).verdict, 'caution');
    eq('what-if no', Calc.whatIf(w, { amount: 1500 }).verdict, 'no');
    eq('what-if after value', Calc.whatIf(w, { amount: 1500 }).after, -500);

    // --- budgets / ranges ---
    var b = mk(); b.budgets = { 'Food & Dining': 1000 }; tx(b, 'expense', 850, { category: 'Food & Dining' });
    eq('budget warn at 85%', Calc.budgetStatus(b, Calc.todayStr().slice(0, 7))[0].status, 'warn');
    tx(b, 'expense', 300, { category: 'Food & Dining' });
    eq('budget over at 115%', Calc.budgetStatus(b, Calc.todayStr().slice(0, 7))[0].status, 'over');
    eq('addMonths wraps year', Calc.addMonths('2026-01', -1), '2025-12');
    eq('addMonths forward', Calc.addMonths('2026-11', 3), '2027-02');
    eq('savings rate', Calc.savingsRate(1000, 750), 25);
    eq('savings rate with no income', Calc.savingsRate(0, 50), null);

    // --- backup export / restore (plan D) ---
    var exp = JSON.parse(JSON.stringify(Calc.exportObject(s)));
    var res = Calc.validateBackup(exp);
    ok('export validates', res.ok);
    eq('round trip keeps balance', Calc.balance(res.state), Calc.balance(s));
    eq('round trip keeps available', Calc.available(res.state), Calc.available(s));
    eq('round trip keeps transaction count', res.state.transactions.length, s.transactions.length);
    ok('rejects array', !Calc.validateBackup([]).ok);
    ok('rejects null', !Calc.validateBackup(null).ok);
    ok('rejects missing transactions', !Calc.validateBackup({ goals: [] }).ok);
    ok('rejects bad amount', !Calc.validateBackup({ transactions: [{ type: 'income', amount: 'x', date: '2026-01-01' }] }).ok);
    ok('rejects bad date', !Calc.validateBackup({ transactions: [{ type: 'income', amount: 5, date: 'yesterday' }] }).ok);
    ok('rejects unknown type', !Calc.validateBackup({ transactions: [{ type: 'gift', amount: 5, date: '2026-01-01' }] }).ok);
    ok('rejects transfer to missing goal', !Calc.validateBackup({ transactions: [{ type: 'transfer', amount: 5, date: '2026-01-01', goalId: 'nope' }] }).ok);
    ok('rejects duplicate ids', !Calc.validateBackup({ transactions: [{ id: 'a', type: 'income', amount: 5, date: '2026-01-01' }, { id: 'a', type: 'income', amount: 6, date: '2026-01-02' }] }).ok);
    var evil = Calc.validateBackup({ transactions: [{ type: 'expense', amount: 5, date: '2026-01-01', title: '<img src=x onerror=alert(1)>', category: 'Bogus' }] });
    ok('unknown category falls back to Other', evil.ok && evil.state.transactions[0].category === 'Other');

    // --- merge duplicates ---
    var m = Calc.mergeStates(s, res.state);
    eq('merge of identical data adds nothing', m.added.transactions, 0);
    ok('merge skips duplicates', m.skipped.transactions === s.transactions.length);
    var more = Calc.validateBackup({ transactions: [{ type: 'income', amount: 77, date: '2026-01-05', title: 'New', category: 'Gift' }] }).state;
    eq('merge adds only new records', Calc.mergeStates(s, more).added.transactions, 1);

    // --- CSV ---
    var c = mk(); tx(c, 'expense', 5, { title: '=HYPERLINK("x")', note: 'a,b' });
    var csv = Calc.toCSV(c);
    ok('csv neutralises formulas', csv.indexOf("'=HYPERLINK") > -1);
    ok('csv quotes commas', csv.indexOf('"a,b"') > -1);

    return { passed: passed, failed: failed };
  }
  if (typeof module !== 'undefined' && module.exports) module.exports = suite;
  root.runFinCanvasTests = suite;
})(typeof window !== 'undefined' ? window : globalThis);
