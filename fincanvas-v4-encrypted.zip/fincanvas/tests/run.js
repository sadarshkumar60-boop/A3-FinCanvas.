// Run with:  node tests/run.js
const Calc = require('../calculations.js');
const suite = require('./calculations.test.js');
const r = suite(Calc, (ok, name, msg) => { if (!ok) console.log('FAIL  ' + name + '  ' + msg); });
console.log(`${r.passed} passed, ${r.failed} failed`);
process.exit(r.failed ? 1 : 0);
